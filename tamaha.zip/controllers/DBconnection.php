<?php 

$server = "localhost";
$user ="root";
$pass = "";
$db = "tamaha";

$connect = mysqli_connect($server, $user, $pass, $db); 

?>